<?php
$servername = "localhost";
$username = "afte_admission_form";
$password = ".4clZw0!)B3!";
$database = "afte_admission_form";
$conn = mysqli_connect($servername, $username, $password, $database);

// $conn = mysqli_connect("localhost", "root", "", "afte");
if (!$conn) {
    die ("Connection failed: ");
}

if (isset ($_POST["submit"])) {
    $enrollment_no = $_POST["enrollment_no"];
    $date_of_admission = $_POST["date_of_admission"];
    $counsellor_name = $_POST["counsellor_name"];
    $handle_by = $_POST["handle_by"];
    $student_name = $_POST["student_name"];
    $father_name = $_POST["father_name"];
    $course = $_POST["course"];
    $session = $_POST["session"];
    $phone = $_POST["phone"];
    $bed = $_POST["bed"];
    $deled = $_POST["deled"];
    $med = $_POST["med"];
    $register_amount = $_POST["register_amount"];
    $register_date = $_POST["register_date"];
    $allotment_amount = $_POST["allotment_amount"];
    $allotment_date = $_POST["allotment_date"];
    $fyr_exam_amount = $_POST["1yr_exam_amount"];
    $fyr_exam_date = $_POST["1yr_exam_date"];
    $syr_exam_amount = $_POST["2yr_exam_amount"];
    $syr_exam_date = $_POST["2yr_exam_date"];
    $migration_fine = $_POST["migration_fine"];
    $practical_file_charge = $_POST["practical_file_charge"];
    $conveyance_charge = $_POST["conveyance_charge"];
    $registration_no = $_POST["registration_no"];
    $password = $_POST["password"];
    $medium = $_POST["medium"];
    $course2 = $_POST["course2"];
    $state = $_POST["state"];
    $session2 = $_POST["session2"];
    $teaching_sub1 = $_POST["teaching_sub1"];
    $teaching_sub2 = $_POST["teaching_sub2"];
    $student_name2 = $_POST["student_name2"];
    $cetegory = $_POST["cetegory"];
    $date_of_birth = $_POST["date_of_birth"];
    $email = $_POST["email"];
    $adhaar = $_POST["adhaar"];
    $gender = $_POST["gender"];
    $phone2 = $_POST["phone2"];
    $phone3 = $_POST["phone3"];
    $father_name2 = $_POST["father_name2"];
    $mother_name = $_POST["mother_name"];
    $address = $_POST["address"];
    $pin = $_POST["pin"];
    $disabilities = $_POST["disabilities"];
    $type_disabilities = $_POST["type_disabilities"];
    $defense_dependent = $_POST["defense_dependent"];
    $dependent = $_POST["dependent"];
    $university_location = $_POST["university_location"];
    $university_group = $_POST["university_group"];
    $university10 = $_POST["university10"];
    $passing_year10 = $_POST["passing_year10"];
    $roll_no10 = $_POST["roll_no10"];
    $obtained10 = $_POST["obtained10"];
    $total_marks10 = $_POST["total_marks10"];
    $per10 = $_POST["per10"];
    $university12 = $_POST["university12"];
    $passing_year12 = $_POST["passing_year12"];
    $roll_no12 = $_POST["roll_no12"];
    $obtained12 = $_POST["obtained12"];
    $total_marks12 = $_POST["total_marks12"];
    $per12 = $_POST["per12"];
    $university_ug = $_POST["university_ug"];
    $passing_year_ug = $_POST["passing_year_ug"];
    $roll_no_ug = $_POST["roll_no_ug"];
    $obtained_ug = $_POST["obtained_ug"];
    $total_marks_ug = $_POST["total_marks_ug"];
    $per_ug = $_POST["per_ug"];
    $university_pg = $_POST["university_pg"];
    $passing_year_pg = $_POST["passing_year_pg"];
    $roll_no_pg = $_POST["roll_no_pg"];
    $obtained_pg = $_POST["obtained_pg"];
    $total_marks_pg = $_POST["total_marks_pg"];
    $per_pg = $_POST["per_pg"];
    $university_other = $_POST["university_other"];
    $passing_year_other = $_POST["passing_year_other"];
    $roll_no_other = $_POST["roll_no_other"];
    $obtained_other = $_POST["obtained_other"];
    $total_marks_other = $_POST["total_marks_other"];
    $per_other = $_POST["per_other"];
    $fee_plan = $_POST["fee_plan"];
    $instrument = $_POST["instrument"];
    $issue_date = $_POST["issue_date"];
    $bank_details = $_POST["bank_details"];
    $amount = $_POST["amount"];
    $instrument2 = $_POST["instrument2"];
    $issue_date2 = $_POST["issue_date2"];
    $bank_details2 = $_POST["bank_details2"];
    $amount2 = $_POST["amount2"];
    $instrument3 = $_POST["instrument3"];
    $issue_date3 = $_POST["issue_date3"];
    $bank_details3 = $_POST["bank_details3"];
    $amount3 = $_POST["amount3"];
    $instrument4 = $_POST["instrument4"];
    $issue_date4 = $_POST["issue_date4"];
    $bank_details4 = $_POST["bank_details4"];
    $amount4 = $_POST["amount4"];
    $agree = $_POST["agree"];
    $agree_date = $_POST["agree_date"];
    $place = $_POST["place"];
    $understand = $_POST["understand"];
    $understand_date = $_POST["understand_date"];
    $place2 = $_POST["place2"];
    $vailid_document = $_POST["vailid_document"];
    $vailid_document_date = $_POST["vailid_document_date"];
    $place3 = $_POST["place3"];
    $sincerity = $_POST["sincerity"];
    $leadership = $_POST["leadership"];
    $imagination = $_POST["imagination"];
    $emotional_stability = $_POST["emotional_stability"];
    $ability = $_POST["ability"];
    $work_hard = $_POST["work_hard"];
    $perseverance = $_POST["perseverance"];
    $declaration = $_POST["declaration"];
    $declaration2 = $_POST["declaration2"];
    $declaration_date = $_POST["declaration_date"];
    $place4 = $_POST["place4"];
    $declaration3 = $_POST["declaration3"];
    $course_admission = $_POST["course_admission"];
    $vailid_photocopy = $_POST["vailid_photocopy"];
    $vailid_photocopy_date = $_POST["vailid_photocopy_date"];
    $place5 = $_POST["place5"];
    $fee_plan2 = $_POST["fee_plan2"];
    $card_before = $_POST["card_before"];
    $concerned = $_POST["concerned"];
    $admit_card = $_POST["admit_card"];
    $admit_card_concerned = $_POST["admit_card_concerned"];
    $student_name3 = $_POST["student_name3"];
    $services = $_POST["services"];
    $student_date = $_POST["student_date"];
    $parents_name = $_POST["parents_name"];
    $parent_address = $_POST["parent_address"];

    $services_imploded = empty ($_POST["services"]) ? " " : implode(",", $services);
    $code = $_POST['code'];

  if (!empty($_FILES['profile_img']['name'])) {
        $images = $_FILES['profile_img']['name'];
        $images_tmp = $_FILES['profile_img']['tmp_name'];
        $profile_dir = "upload/";
        $profile_newname = $code . "_std_pro_photo" . "." . pathinfo($_FILES['profile_img']['name'], PATHINFO_EXTENSION);
        $targetfile = $profile_dir . $profile_newname;
        move_uploaded_file($images_tmp, $targetfile);
    }
    if (!empty($_FILES['student_signature']['name'])) {
        $images2 = $_FILES['student_signature']['name'];
        $images_tmp = $_FILES['student_signature']['tmp_name'];
        $student_signature_dir = "upload/";
        $student_signature_newname = $code . "_std_sig_photo" . "." . pathinfo($_FILES['student_signature']['name'], PATHINFO_EXTENSION);
        $targetfile2 = $student_signature_dir . $student_signature_newname;
        move_uploaded_file($images_tmp, $targetfile2);
    }
    if (!empty($_FILES['parent_signature_sig']['name'])) {
        $images3 = $_FILES['parent_signature_sig']['name'];
        $images_tmp = $_FILES['parent_signature_sig']['tmp_name'];
        $parent_signature_sig_dir = "upload/";
        $parent_signature_sig_newname = $code . "_prt_sig_photo" . "." . pathinfo($_FILES['parent_signature_sig']['name'], PATHINFO_EXTENSION);
        $targetfile3 = $parent_signature_sig_dir . $parent_signature_sig_newname;
        move_uploaded_file($images_tmp, $targetfile3);
    }


  echo  $sql = "INSERT INTO all_data (enroll_code,profile_img, enrollment_no, date_of_admission, counsellor_name, handle_by, student_name, father_name, course, session, phone, bed, deled, med, register_amount, register_date, allotment_amount, allotment_date, 1yr_exam_amount, 1yr_exam_date, 2yr_exam_amount, 2yr_exam_date, migration_fine, practical_file_charge, conveyance_charge, registration_no, password, medium, course2, state, session2, teaching_sub1, teaching_sub2, student_name2, cetegory, date_of_birth, email, adhaar, gender, phone2, phone3, father_name2, mother_name, address, pin, disabilities, type_disabilities, defense_dependent, dependent, university_location, university_group, university10, passing_year10, roll_no10, obtained10, total_marks10, per10, university12, passing_year12, roll_no12, obtained12, total_marks12, per12, university_ug, passing_year_ug, roll_no_ug, obtained_ug, total_marks_ug, per_ug, university_pg, passing_year_pg, roll_no_pg, obtained_pg, total_marks_pg, per_pg, university_other, passing_year_other, roll_no_other, obtained_other, total_marks_other, per_other, fee_plan, instrument, issue_date, bank_details, amount, instrument2, issue_date2, bank_details2, amount2, instrument3, issue_date3, bank_details3, amount3, instrument4, issue_date4, bank_details4, amount4, agree, agree_date, place, understand, understand_date, place2, vailid_document, vailid_document_date, place3, sincerity, leadership, imagination, emotional_stability, ability, work_hard, perseverance, declaration, declaration2, declaration_date, place4, declaration3, course_admission, vailid_photocopy, vailid_photocopy_date, place5, fee_plan2, card_before, concerned, admit_card, admit_card_concerned,student_signature,parent_signature_sig,services,student_name3,student_date,parents_name,parent_address) VALUES ('$code','$profile_newname','$enrollment_no','$date_of_admission','$counsellor_name','$handle_by','$student_name','$father_name','$course','$session','$phone','$bed','$deled','$med','$register_amount','$register_date','$allotment_amount','$allotment_date','$fyr_exam_amount','$fyr_exam_date','$syr_exam_amount','$syr_exam_date','$migration_fine','$practical_file_charge','$conveyance_charge','$registration_no','$password','$medium','$course2','$state','$session2','$teaching_sub1','$teaching_sub2','$student_name2','$cetegory','$date_of_birth','$email','$adhaar','$gender','$phone2','$phone3','$father_name2','$mother_name','$address','$pin','$disabilities','$type_disabilities','$defense_dependent','$dependent','$university_location','$university_group','$university10','$passing_year10','$roll_no10','$obtained10','$total_marks10','$per10','$university12','$passing_year12','$roll_no12','$obtained12','$total_marks12','$per12','$university_ug','$passing_year_ug','$roll_no_ug','$obtained_ug','$total_marks_ug','$per_ug','$university_pg','$passing_year_pg','$roll_no_pg','$obtained_pg','$total_marks_pg','$per_pg','$university_other','$passing_year_other','$roll_no_other','$obtained_other','$total_marks_other','$per_other','$fee_plan','$instrument','$issue_date','$bank_details','$amount','$instrument2','$issue_date2','$bank_details2','$amount2','$instrument3','$issue_date3','$bank_details3','$amount3','$instrument4','$issue_date4','$bank_details4','$amount4','$agree','$agree_date','$place','$understand','$understand_date','$place2','$vailid_document','$vailid_document_date','$place3','$sincerity','$leadership','$imagination','$emotional_stability','$ability','$work_hard','$perseverance','$declaration','$declaration2','$declaration_date','$place4','$declaration3','$course_admission','$vailid_photocopy','$vailid_photocopy_date','$place5','$fee_plan2','$card_before','$concerned','$admit_card','$admit_card_concerned','$student_signature_newname','$parent_signature_sig_newname','$services_imploded','$student_name3','$student_date','$parents_name','$parent_address')";

    if (mysqli_query($conn, $sql)) {
        echo "<script language='javascript'>";
        echo "alert('Admission Form Submitted Successfully.We Are Contact To You Shortly..!');";
        echo 'window.location.replace("index.php");';
        echo "</script>";
    } else {
        mysqli_error($conn);
    }


}

?>